#include<iostream>
#include<fstream>
#include "formula.hpp"
using namespace std;

void formula()
{
	char ch;
	const char *fileName="test.txt";
	
	//declare object
	ifstream file;
	
	//open file
	file.open("formula.txt",ios::in);
	if(!file)
	{
		cout<<"Error in opening file!!!"<<endl;
		 //return from main
	}
	
	//read and print file content
	while (!file.eof()) 
	{
		file >> noskipws >> ch;	//reading from file
		cout << ch;	//printing
	}
	//close the file
	file.close();
	
	
}
