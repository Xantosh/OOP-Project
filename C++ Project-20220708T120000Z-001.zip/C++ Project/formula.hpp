void formula();
