
class Intregation{
    float x;
    char s[100];
  public:
  	
  	 Intregation(float  );
  	 float F(float );
  	  float finder();
  };
  void task();
  void Intewelcome();
