class matrix;
void mat();

