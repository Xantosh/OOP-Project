#include <iostream>
#include <iomanip>
#include <math.h>
#include "matrix.hpp"
using namespace std;
class matrix
{
	int n,i,j,k,r,c,*status;
	
	float factor,factor1,temp1,temp;

	float a[20][20],x[20],t[20];
	
	

	public:matrix()
	{
		
	}

	void input()
	{
		
		cout<<"ENTER IN THE FORMAT OF AX+BY+CZ=D"<<endl;
		cout<<"HERE    a11 represents coefficients of x1 "<<endl<<" a12 represents coefficients of y1" <<endl<<" a13 represents coefficient of z1"<<endl<<"a14 represents the constant on right side(d)"<<endl;
		cout<<"ENTER THE SIZE OF LINEAR SYSTEM (NUMBER OF UNKOWNS) : ";
		cin>>n;
	    cout.precision(4);
		
	
		for(i=1;i<=n;i++) //input for coefficients
		{
			for(j=1;j<=n+1;j++)
			{
				cout<<"a"<<i<<j<<" : ";
				cin>>a[i][j];
			
			}
		}
		cout<<"ENTERED VALUE IN MATRIX FORM : "<<endl;//showing the input values in matrix form
		{
			for (i=1;i<=n;i++)
			{
				for(j=1;j<=n+1;j++)
				{
					if(j==n+1)
					{
						cout<<" : ";
					}
					cout<<" "<<a[i][j];
					
					if(j==n+1)
					{
						cout<<endl<<endl;
					}
				}
			}
		}
		
	}
	void pivot()//complete pivoting method
	{
	      int e=1;
	
	    temp=a[e][e];
		for(j=1;j<=n;j++)
		{
		   if(abs(temp)<abs(a[j][e]))
		   {
		   	temp=abs(a[j][e]);
		   }
		
		}
		for(r=1;r<=n;r++)
		{	if(temp==abs(a[r][e]))
				{
					for(c=1;c<=n+1;c++)
					{
					  t[c]=a[e][c];
					  a[e][c]=a[r][c];
					  a[r][c]=t[c];
				    }
			   }
	    }
	}
	
	void partialpivot(int e)
	{
	   
	
	    temp=a[e][e];
		for(j=e;j<=n;j++)
	  {
		   if(abs(temp)<abs(a[j][e]))
		{
		   	temp=(a[j][e]);
		   
		
		
		     for(r=j;r<=n;r++)
		    {	
			     if(temp==a[r][e])
				{
					for(c=1;c<=n+1;c++)
					{
					  t[c]=a[e][c];
					  a[e][c]=a[r][c];
					  a[r][c]=t[c];
				    }
				    
				}
		    }
		}
	  }
	}
	
	
	
	void gauss2()//gauss elimination for row echelon form
	{
		for(k=1;k<=n-1;k++)//algorithm
		{
			for(i=k;i<=n-1;i++)
			{
					factor=abs(a[i+1][k]);
					factor1=abs(a[k][k]);
					
					if (a[k][k]<0 && a[i+1][k]>0)
			    { 
			
			     	for(j=1;j<=n+1;j++)
			    	{
				    	a[i+1][j]=(a[i+1][j]*factor1)+(factor*a[k][j]);
				    }
		       }  
			    else if(a[k][k]>0 && a[i+1][k]<0)
		     	{
					for(j=1;j<=n+1;j++)
			    	{
				    	a[i+1][j]=(a[i+1][j]*factor1)+(factor*a[k][j]);
				    }	
		    	}
		    	 else
		    	 {
		    	 	for(j=1;j<=n+1;j++)
		    	 	{
						 
		    	 	a[i+1][j]=(a[i+1][j]*factor1)-(factor*a[k][j]);
		    	    }
				 }
				
			
	    	}
	    	partialpivot(k+1);
	    	check();
		}
	}
	void div()
	{
		
		for(i=1;i<=n;i++)
		{
			temp1=a[i][i];
			{
				for(j=1;j<=n+1;j++)
				{
					a[i][j]=a[i][j]/temp1;
				}
			}
		}
	}
	void backsub()//sub value after the elimination to find the solution....
	{
		
	
		
			x[n]=a[n][n+1];
			for(i=n-1;i>=1;i--)
			{
			     float sum=0.0;	
				
				for(j=i+1;j<=n;j++)
				{
				//product=x[j]*a[i][j];	
				sum=sum+x[j]*a[i][j];
				x[i]=a[i][n+1]-sum;
					
					
				}
				
			
				
			}
		
	}
	void solution()
	{
	if(a[n][n]==0 && a[n][n+1]==0)
	{
		cout <<"either no solution or infinte solution"<<endl;
	}

	else
	{
		cout<<"   SOLUTIONS  "<<endl;
		
		for(i=1;i<=n;i++)
		{
			
			cout<<"x"<<i<<" = "<<x[i]<<ends;
		}
	  }
	}
	
	void check()
	{
		cout<<"check for elimination "<<endl;
		{
			for (i=1;i<=n;i++)
			{
				for(j=1;j<=n+1;j++)
				{
					if(j==n+1)
					{
						cout<<" : ";
					}
					cout<<" "<<a[i][j];
					
					if(j==n+1)
					{
						cout<<endl<<endl;
					}
				}
			}
		}
		
	}
};
void mat()
{
	matrix m;
	m.input();
	m.pivot();
//	m.check();
	m.gauss2();
	m.div();
	//m.check();
	m.backsub();
	m.solution();
	//m.backsub();
	
//	return 0;
	//getch();
}

