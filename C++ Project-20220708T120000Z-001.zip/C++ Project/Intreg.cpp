#include <iostream>
#include<sstream>
#include <string.h>
#include<math.h>
#include"Intreg.hpp"
#include<fstream>
using namespace std;


   Intregation:: Intregation(float a=(3.14/4)  ){
    x=a;
     cout<<"Enter the function "<<endl;
  cin>>s;


    }
    //This function finds the constant
  float Intregation ::  F(float temp){
      x=temp;
      float f=1;
      int a=0,b=1;
      char as[100];
      for (int i=0;i<100;i++){
        if (s[i]!='1'&& s[i]!='2' && s[i]!='3' && s[i]!='4'&& s[i]!='5'&& s[i]!='6'&& s[i]!='7'&& s[i]!='8'&& s[i]!='9'&& s[i]!='0'){
          a=i;
           goto label;
        }


      }
      label:

      for(int j=0;j<a;j++){
        as[j]=s[j];
      }
      //cout<<as<<endl;
      if(a>0){

      stringstream geek(as);
      geek>>b;

  }
  	//cout<<b<<endl;
  	//system("CLS");
		f=b*f*finder();
	//cout<<f<<endl;

	return f;
    }
    //This is the big dog that finds the function
  float Intregation ::  finder(){
      float f=1;
      int c=0,fc=1;
      int *a;
      int b=0;
      char d[10];
      int t;
      int n=1;

      for(int i =0;i<100;i++){
        if(s[i]=='x'){
          c++;

        }

      }
      a= new int[c];//position of x
      for( int i =0;i<100;i++){//how many x
        if(s[i]=='x'){
          a[b]=i;
          b++;

        }

      }

		//cout<<c<<endl;
      for(int z=0;z<c;z++){ 
		//cout<<a[z]<<endl;

        for (int j=a[z]-1;j>=0;j--){
          if(s[j]=='('){
          	t=0;
            for(int i=j+1;i<a[z];i++){
              d[t]=s[i];
              t++;

            }
            //cout<<t<<endl;
			if (t>=1){
			
            stringstream pot(d);
           pot>>n;}
           //cout<<n<<endl;
           if(s[j-1]=='e'){
            f=f* exp(n*x);
            //cout<<f<<endl;
           }
           else if(s[j-1]=='n'&& s[j-2]=='a' && s[j-3]=='t'){
             f=f*tan(n*x);
				//cout<<f<<endl;
           }
           else if(s[j-1]=='n'&& s[j-2]=='i' && s[j-3]=='s'){
             f=f*sin(n*x);
			//	cout<<f<<endl;
           }
           else if(s[j-1]=='s'&& s[j-2]=='o' && s[j-3]=='c'){
             f=f*cos(n*x);

           }
           else if(s[j-1]=='c'&& s[j-2]=='e' && s[j-3]=='s' && s[j-4]=='o' && s[j-5]=='c'){
             f=f/sin(n*x);

           }

           else if(s[j-1]=='c'&& s[j-2]=='e' && s[j-3]=='s'){
             f=f/cos(n*x);

           }
           else if(s[j-1]=='t'&& s[j-2]=='o' && s[j-3]=='c'){
             f=f/tan(n*x);

           }
           else if(s[j-1]=='g'&& s[j-2]=='o' && s[j-3]=='l'){
             f=f*log(n*x);

           }
            else if(s[j-1]=='h'&&s[j-2]=='n'&& s[j-3]=='i' && s[j-4]=='s'){
             f=f*sinh(n*x);
			//	cout<<f<<endl;
           }
            else if(s[j-1]=='h' && s[j-2]=='s'&& s[j-3]=='o' && s[j-4]=='c'){
             f=f*cosh(n*x);

           }
            else if(s[j-1]=='h'&&s[j-2]=='n'&& s[j-3]=='a' && s[j-4]=='t'){
             f=f*tanh(n*x);
				//cout<<f<<endl;
           }
           else if(s[j-1]=='h' && s[j-2]=='c'&& s[j-3]=='e' && s[j-4]=='s' && s[j-5]=='o' && s[j-6]=='c'){
             f=f/sinh(n*x);

           }
            else if(s[j-1]=='h'&&s[j-2]=='c'&& s[j-3]=='e' && s[j-4]=='s'){
             f=f/cosh(n*x);

           }
           else if(s[j-1]=='h'&&s[j-2]=='t'&& s[j-3]=='o' && s[j-4]=='c'){
             f=f/tanh(n*x);

           }
           else{
             f=f*x;
           }

           break;


          }

        }





	  }


		return f;
    }
    
    void Intewelcome(){
    	
    		
		char ch;
	const char *fileName="test.txt";
	
	
	ifstream file;
	
	
	file.open("integhelp.txt",ios::in);
	if(!file)
	{
		cout<<"Error in opening file!!!"<<endl;
		 
	}
	
	//read and print file content
	while (!file.eof()) 
	{
		file >> noskipws >> ch;	//reading from file
		cout << ch;	//printing
	}
	
	file.close();
    	
	}

void task(){

	float b,a,h,x,y;
  Intregation p;
  cout<<"Enter upper limit:";
  cin>>b;
  cout<<"Enter lower limit:";
  cin>>a;
  h=(b-a)/100;
  y=a;
  x=p.F(a);
  //cout<<x;
  for(int i=1 ; i<100;i++){
    y=y+h;
    x=x+2*p.F(y);
    
  }
  x=x+p.F(b);
  x=(h*x)/2;
  cout<<"The integral is : "<<x<<endl;
  //cout<<p.F(3.14/4)<<endl;
  //cout<<cos(3.14*5/4);


}

/*int main(){
  task();
  return 0;}*/
