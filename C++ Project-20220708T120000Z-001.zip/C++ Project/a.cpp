#include <iostream>
#include <math.h>
#include "a.hpp"
using namespace std;
  void cylinder::output(){
    cout<<"rho:"<<rho<<endl;
    cout<<"phi:"<<phi<<endl;
    cout<<"z:"<<z;
  }

  cylinder::cylinder(float arg_rho,float arg_phi,float arg_z){
    rho=arg_rho;
    phi=arg_phi;
    z=arg_z;
    output();

  }


  void sphere:: printer(){
    cout<<"r:"<<r<<endl;
    cout<<"theta:"<<theta<<endl;
    cout<<"phi:"<<phi;
  }


  sphere :: sphere(float arg_r,float arg_theta ,float arg_phi){
    r=arg_r;
    theta=arg_theta;
    phi=arg_phi;
   // cout<<phi<<endl;
    printer();

  }



  void cart:: call_class_cylinder(){
    cylinder a(dummy_rho,dummy_phi,pz);

  }
  void cart:: call_class_sphere(){
  	cout<<dummy_phi<<endl;
    sphere s1(dummy_r,dummy_theta,dummy_phi);
  }
  
  cart::cart( float ax,float ay,float az){
    px=ax;
    py=ay;
    pz=az;
  }
  void cart::getangle(float get_angle){
    angle=get_angle*(3.14/180);
  }
  void cart::calculate_cylinderical(){
    dummy_rho=px*cos(angle)+ py*sin(angle);
    dummy_phi=-px*sin(angle)+py*cos(angle);
    call_class_cylinder();
  }
  void cart::calculate_spherical(){
    float t;
    cout<<"angle(theta)"<<endl;
    cin>>t;
    t=t*(3.14/180);

    dummy_r=px*sin(t)*cos(angle)+py*sin(t)*sin(angle)+pz*cos(t);
    dummy_theta=px*cos(t)*cos(angle)+py*cos(t)*sin(angle)+pz*(-sin(t));
    dummy_phi=-px*sin(angle)+py*cos(angle);
    call_class_sphere();
  }

  



void docalc(){
  float x,y,z;
   float a;
   float b;
  int n;
  cout<<"Write the rectangular components"<<endl;
  cout<<"ax:"<<endl;
  cin>>x;
  cout <<"ay:"<<endl;
  cin>>y;

  cout<<"az:"<<endl;
  cin>>z;
  cout<<"angle (phi)";
  cin>> a;
  cart c1(x,y,z);
	c1.getangle(a);
  cout<<"What do you want to convert to :"<<endl;
  cout<<"1.Cylinderical"<<endl;
  cout<<"2.Spherical"<<endl;

  cin>>n;
  switch (n){
    case 1:
   
    c1.calculate_cylinderical();
    break;
    case 2:
    c1.calculate_spherical();
    break;
  }




}
