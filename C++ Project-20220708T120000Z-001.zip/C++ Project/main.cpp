#include<iostream>
#include "Intreg.hpp"
#include "formula.hpp"
#include "a.hpp"
#include "matrix.hpp"
#include<fstream>
using namespace std;

void welcome()

{
	
		char ch;
	const char *fileName="test.txt";
	
	
	ifstream file;
	
	
	file.open("Welcome.txt",ios::in);
	if(!file)
	{
		cout<<"Error in opening file!!!"<<endl;
		 
	}
	
	//read and print file content
	while (!file.eof()) 
	{
		file >> noskipws >> ch;	//reading from file
		cout << ch;	//printing
	}
	
	file.close();
	
}
int main(){
	welcome();
 // cout<<"Welcome to SSC "<<endl;
  int n;
  cout<<endl;
  cout<<endl;cout<<endl;cout<<endl;
  cout<<"What do you want to do"<<endl;
  cout<<"1.Intregation"<<endl;
  cout<<"2.List formulae"<<endl;
  cout<<"3.Do transformation"<<endl;
  cout<<"4.linear equation solution"<<endl;
  cin>>n;
  switch (n){
  
  case 1:
	Intewelcome();	
	cout<<endl;
  task();
 break;
 case 2:
 formula();
 	break;
	case 3:
		docalc();
		break;
	case 4:
		mat();
		break;
}
}
