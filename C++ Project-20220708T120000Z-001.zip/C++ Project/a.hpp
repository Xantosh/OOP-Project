class cylinder{
private:
  float rho;
  float phi;
  float z;
  void output();
public:
  cylinder(float arg_rho,float arg_phi,float arg_z);

};

class sphere{
private:
  float r;
  float theta;
  float phi;
  void printer();
public:
  sphere(float arg_r,float arg_theta ,float arg_phi);

};
class cart{
private:
  float px;
  float py;
  float pz;
  float angle;
  float dummy_rho;
  float dummy_phi;
  float dummy_theta;
  float dummy_r;
  void call_class_cylinder();
 
  void call_class_sphere();
 
  public:
  cart( float ax,float ay,float az);
 
  void getangle(float get_angle);
 
  void calculate_cylinderical();   
  void calculate_spherical();


  };
  void docalc();

